module imonitor {
	requires java.desktop;
	requires java.logging;
}