autoreconf -vi
./configure
make all
